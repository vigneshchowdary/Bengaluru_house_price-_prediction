.. code:: ipython3

    import pandas as pd
    import numpy as np
    from matplotlib import pyplot as plt
    import matplotlib
    import warnings
    warnings.filterwarnings('ignore')

.. code:: ipython3

    df=pd.read_csv(r"C:\Users\Vignesh Chowdary\OneDrive\Documents\Downloads\Bengaluru_House_Data.csv")

.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>area_type</th>
          <th>availability</th>
          <th>location</th>
          <th>size</th>
          <th>society</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>balcony</th>
          <th>price</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Super built-up  Area</td>
          <td>19-Dec</td>
          <td>Electronic City Phase II</td>
          <td>2 BHK</td>
          <td>Coomee</td>
          <td>1056</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>39.07</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Plot  Area</td>
          <td>Ready To Move</td>
          <td>Chikka Tirupathi</td>
          <td>4 Bedroom</td>
          <td>Theanmp</td>
          <td>2600</td>
          <td>NaN</td>
          <td>3.0</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Built-up  Area</td>
          <td>Ready To Move</td>
          <td>Uttarahalli</td>
          <td>3 BHK</td>
          <td>NaN</td>
          <td>1440</td>
          <td>2.0</td>
          <td>3.0</td>
          <td>62.00</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Super built-up  Area</td>
          <td>Ready To Move</td>
          <td>Lingadheeranahalli</td>
          <td>3 BHK</td>
          <td>Soiewre</td>
          <td>1521</td>
          <td>3.0</td>
          <td>1.0</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Super built-up  Area</td>
          <td>Ready To Move</td>
          <td>Kothanur</td>
          <td>2 BHK</td>
          <td>NaN</td>
          <td>1200</td>
          <td>2.0</td>
          <td>1.0</td>
          <td>51.00</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.shape




.. parsed-literal::

    (13320, 9)



.. code:: ipython3

    
    df.columns




.. parsed-literal::

    Index(['area_type', 'availability', 'location', 'size', 'society',
           'total_sqft', 'bath', 'balcony', 'price'],
          dtype='object')



.. code:: ipython3

    df.size




.. parsed-literal::

    119880



.. code:: ipython3

    df2=df.drop(["area_type","availability","society","balcony"],axis="columns")

.. code:: ipython3

    df2.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Electronic City Phase II</td>
          <td>2 BHK</td>
          <td>1056</td>
          <td>2.0</td>
          <td>39.07</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Chikka Tirupathi</td>
          <td>4 Bedroom</td>
          <td>2600</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Uttarahalli</td>
          <td>3 BHK</td>
          <td>1440</td>
          <td>2.0</td>
          <td>62.00</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Lingadheeranahalli</td>
          <td>3 BHK</td>
          <td>1521</td>
          <td>3.0</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Kothanur</td>
          <td>2 BHK</td>
          <td>1200</td>
          <td>2.0</td>
          <td>51.00</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df2.isnull().sum()




.. parsed-literal::

    location       1
    size          16
    total_sqft     0
    bath          74
    price          3
    dtype: int64



.. code:: ipython3

    df3=df2.dropna()

.. code:: ipython3

    df3.isnull().sum()




.. parsed-literal::

    location      0
    size          0
    total_sqft    0
    bath          0
    price         0
    dtype: int64



.. code:: ipython3

    df3.shape




.. parsed-literal::

    (13243, 5)



.. code:: ipython3

    df3['bhk'] = df3['size'].apply(lambda x: int(x.split(' ')[0]))

.. code:: ipython3

    df3.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Electronic City Phase II</td>
          <td>2 BHK</td>
          <td>1056</td>
          <td>2.0</td>
          <td>39.07</td>
          <td>2</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Uttarahalli</td>
          <td>3 BHK</td>
          <td>1440</td>
          <td>2.0</td>
          <td>62.00</td>
          <td>3</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Kothanur</td>
          <td>2 BHK</td>
          <td>1200</td>
          <td>2.0</td>
          <td>51.00</td>
          <td>2</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Whitefield</td>
          <td>2 BHK</td>
          <td>1170</td>
          <td>2.0</td>
          <td>38.00</td>
          <td>2</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Rajaji Nagar</td>
          <td>4 BHK</td>
          <td>3300</td>
          <td>4.0</td>
          <td>600.00</td>
          <td>4</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df3["total_sqft"].unique()




.. parsed-literal::

    array(['1056', '1440', '1200', ..., '1133 - 1384', '774', '4689'],
          dtype=object)



.. code:: ipython3

    def is_float(x):
        try:
            float(x)
        except:
            return False
        return True

.. code:: ipython3

    df3[~df3['total_sqft'].apply(is_float)].head(7)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>30</th>
          <td>Yelahanka</td>
          <td>4 BHK</td>
          <td>2100 - 2850</td>
          <td>4.0</td>
          <td>186.000</td>
          <td>4</td>
        </tr>
        <tr>
          <th>122</th>
          <td>Hebbal</td>
          <td>4 BHK</td>
          <td>3067 - 8156</td>
          <td>4.0</td>
          <td>477.000</td>
          <td>4</td>
        </tr>
        <tr>
          <th>137</th>
          <td>8th Phase JP Nagar</td>
          <td>2 BHK</td>
          <td>1042 - 1105</td>
          <td>2.0</td>
          <td>54.005</td>
          <td>2</td>
        </tr>
        <tr>
          <th>165</th>
          <td>Sarjapur</td>
          <td>2 BHK</td>
          <td>1145 - 1340</td>
          <td>2.0</td>
          <td>43.490</td>
          <td>2</td>
        </tr>
        <tr>
          <th>188</th>
          <td>KR Puram</td>
          <td>2 BHK</td>
          <td>1015 - 1540</td>
          <td>2.0</td>
          <td>56.800</td>
          <td>2</td>
        </tr>
        <tr>
          <th>410</th>
          <td>Kengeri</td>
          <td>1 BHK</td>
          <td>34.46Sq. Meter</td>
          <td>1.0</td>
          <td>18.500</td>
          <td>1</td>
        </tr>
        <tr>
          <th>549</th>
          <td>Hennur Road</td>
          <td>2 BHK</td>
          <td>1195 - 1440</td>
          <td>2.0</td>
          <td>63.770</td>
          <td>2</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    def convert_sqft_to_num(x):
        tokens = x.split('-')
        if len(tokens) == 2:
            return (float(tokens[0])+float(tokens[1]))/2
        try:
            return float(x)
        except:
            return None

.. code:: ipython3

    df4 = df3.copy()
    df4.total_sqft=df4.total_sqft.apply(convert_sqft_to_num)
    df4.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Electronic City Phase II</td>
          <td>2 BHK</td>
          <td>1056.0</td>
          <td>2.0</td>
          <td>39.07</td>
          <td>2</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Uttarahalli</td>
          <td>3 BHK</td>
          <td>1440.0</td>
          <td>2.0</td>
          <td>62.00</td>
          <td>3</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Kothanur</td>
          <td>2 BHK</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>51.00</td>
          <td>2</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Whitefield</td>
          <td>2 BHK</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>38.00</td>
          <td>2</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Rajaji Nagar</td>
          <td>4 BHK</td>
          <td>3300.0</td>
          <td>4.0</td>
          <td>600.00</td>
          <td>4</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df4["price_per_sqft"]=df4["price"]*100000/df4["total_sqft"]
    df4.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>price_per_sqft</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Electronic City Phase II</td>
          <td>2 BHK</td>
          <td>1056.0</td>
          <td>2.0</td>
          <td>39.07</td>
          <td>2</td>
          <td>3699.810606</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Uttarahalli</td>
          <td>3 BHK</td>
          <td>1440.0</td>
          <td>2.0</td>
          <td>62.00</td>
          <td>3</td>
          <td>4305.555556</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Kothanur</td>
          <td>2 BHK</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>51.00</td>
          <td>2</td>
          <td>4250.000000</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Whitefield</td>
          <td>2 BHK</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>38.00</td>
          <td>2</td>
          <td>3247.863248</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Rajaji Nagar</td>
          <td>4 BHK</td>
          <td>3300.0</td>
          <td>4.0</td>
          <td>600.00</td>
          <td>4</td>
          <td>18181.818182</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    locations=df4["location"].value_counts()
    locations
    




.. parsed-literal::

    Whitefield                                         534
    Sarjapur  Road                                     392
    Electronic City                                    302
    Kanakpura Road                                     266
    Thanisandra                                        233
                                                      ... 
    Dwaraka Nagar                                        1
    GKW Layout                                           1
    6th block banashankari 3rd stage, 100 feet ORR       1
    Ex-Servicemen Colony Dinnur Main Road R.T.Nagar      1
    Manonarayanapalya                                    1
    Name: location, Length: 1304, dtype: int64



.. code:: ipython3

    len(locations)




.. parsed-literal::

    1304



.. code:: ipython3

    len(locations[locations<=10])




.. parsed-literal::

    1063



.. code:: ipython3

    len(locations[locations>10])




.. parsed-literal::

    241



.. code:: ipython3

    locations_lessthan_10=locations[locations<=10]

.. code:: ipython3

    locations_lessthan_10




.. parsed-literal::

    Dairy Circle                                       10
    Kalkere                                            10
    Nagappa Reddy Layout                               10
    Dodsworth Layout                                   10
    Naganathapura                                      10
                                                       ..
    Dwaraka Nagar                                       1
    GKW Layout                                          1
    6th block banashankari 3rd stage, 100 feet ORR      1
    Ex-Servicemen Colony Dinnur Main Road R.T.Nagar     1
    Manonarayanapalya                                   1
    Name: location, Length: 1063, dtype: int64



.. code:: ipython3

    df4.location.nunique()




.. parsed-literal::

    1304



.. code:: ipython3

    df4.location=df4.location.apply(lambda x: "other" if x in locations_lessthan_10 else x)
    df4.head(15)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>price_per_sqft</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Electronic City Phase II</td>
          <td>2 BHK</td>
          <td>1056.0</td>
          <td>2.0</td>
          <td>39.07</td>
          <td>2</td>
          <td>3699.810606</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Uttarahalli</td>
          <td>3 BHK</td>
          <td>1440.0</td>
          <td>2.0</td>
          <td>62.00</td>
          <td>3</td>
          <td>4305.555556</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Kothanur</td>
          <td>2 BHK</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>51.00</td>
          <td>2</td>
          <td>4250.000000</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Whitefield</td>
          <td>2 BHK</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>38.00</td>
          <td>2</td>
          <td>3247.863248</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Rajaji Nagar</td>
          <td>4 BHK</td>
          <td>3300.0</td>
          <td>4.0</td>
          <td>600.00</td>
          <td>4</td>
          <td>18181.818182</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Marathahalli</td>
          <td>3 BHK</td>
          <td>1310.0</td>
          <td>3.0</td>
          <td>63.25</td>
          <td>3</td>
          <td>4828.244275</td>
        </tr>
        <tr>
          <th>9</th>
          <td>other</td>
          <td>6 Bedroom</td>
          <td>1020.0</td>
          <td>6.0</td>
          <td>370.00</td>
          <td>6</td>
          <td>36274.509804</td>
        </tr>
        <tr>
          <th>10</th>
          <td>Whitefield</td>
          <td>3 BHK</td>
          <td>1800.0</td>
          <td>2.0</td>
          <td>70.00</td>
          <td>3</td>
          <td>3888.888889</td>
        </tr>
        <tr>
          <th>11</th>
          <td>Whitefield</td>
          <td>4 Bedroom</td>
          <td>2785.0</td>
          <td>5.0</td>
          <td>295.00</td>
          <td>4</td>
          <td>10592.459605</td>
        </tr>
        <tr>
          <th>12</th>
          <td>7th Phase JP Nagar</td>
          <td>2 BHK</td>
          <td>1000.0</td>
          <td>2.0</td>
          <td>38.00</td>
          <td>2</td>
          <td>3800.000000</td>
        </tr>
        <tr>
          <th>13</th>
          <td>Gottigere</td>
          <td>2 BHK</td>
          <td>1100.0</td>
          <td>2.0</td>
          <td>40.00</td>
          <td>2</td>
          <td>3636.363636</td>
        </tr>
        <tr>
          <th>14</th>
          <td>Sarjapur</td>
          <td>3 Bedroom</td>
          <td>2250.0</td>
          <td>3.0</td>
          <td>148.00</td>
          <td>3</td>
          <td>6577.777778</td>
        </tr>
        <tr>
          <th>15</th>
          <td>Mysore Road</td>
          <td>2 BHK</td>
          <td>1175.0</td>
          <td>2.0</td>
          <td>73.50</td>
          <td>2</td>
          <td>6255.319149</td>
        </tr>
        <tr>
          <th>16</th>
          <td>Bisuvanahalli</td>
          <td>3 BHK</td>
          <td>1180.0</td>
          <td>3.0</td>
          <td>48.00</td>
          <td>3</td>
          <td>4067.796610</td>
        </tr>
        <tr>
          <th>17</th>
          <td>Raja Rajeshwari Nagar</td>
          <td>3 BHK</td>
          <td>1540.0</td>
          <td>3.0</td>
          <td>60.00</td>
          <td>3</td>
          <td>3896.103896</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df4[df4["total_sqft"]/df4["bhk"]<300].head(15)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>price_per_sqft</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>9</th>
          <td>other</td>
          <td>6 Bedroom</td>
          <td>1020.0</td>
          <td>6.0</td>
          <td>370.0</td>
          <td>6</td>
          <td>36274.509804</td>
        </tr>
        <tr>
          <th>45</th>
          <td>HSR Layout</td>
          <td>8 Bedroom</td>
          <td>600.0</td>
          <td>9.0</td>
          <td>200.0</td>
          <td>8</td>
          <td>33333.333333</td>
        </tr>
        <tr>
          <th>58</th>
          <td>Murugeshpalya</td>
          <td>6 Bedroom</td>
          <td>1407.0</td>
          <td>4.0</td>
          <td>150.0</td>
          <td>6</td>
          <td>10660.980810</td>
        </tr>
        <tr>
          <th>68</th>
          <td>other</td>
          <td>8 Bedroom</td>
          <td>1350.0</td>
          <td>7.0</td>
          <td>85.0</td>
          <td>8</td>
          <td>6296.296296</td>
        </tr>
        <tr>
          <th>70</th>
          <td>other</td>
          <td>3 Bedroom</td>
          <td>500.0</td>
          <td>3.0</td>
          <td>100.0</td>
          <td>3</td>
          <td>20000.000000</td>
        </tr>
        <tr>
          <th>78</th>
          <td>Kaval Byrasandra</td>
          <td>2 BHK</td>
          <td>460.0</td>
          <td>1.0</td>
          <td>22.0</td>
          <td>2</td>
          <td>4782.608696</td>
        </tr>
        <tr>
          <th>89</th>
          <td>Rajaji Nagar</td>
          <td>6 Bedroom</td>
          <td>710.0</td>
          <td>6.0</td>
          <td>160.0</td>
          <td>6</td>
          <td>22535.211268</td>
        </tr>
        <tr>
          <th>119</th>
          <td>Hennur Road</td>
          <td>2 Bedroom</td>
          <td>276.0</td>
          <td>3.0</td>
          <td>23.0</td>
          <td>2</td>
          <td>8333.333333</td>
        </tr>
        <tr>
          <th>129</th>
          <td>Vishwapriya Layout</td>
          <td>7 Bedroom</td>
          <td>950.0</td>
          <td>7.0</td>
          <td>115.0</td>
          <td>7</td>
          <td>12105.263158</td>
        </tr>
        <tr>
          <th>149</th>
          <td>other</td>
          <td>6 Bedroom</td>
          <td>1034.0</td>
          <td>5.0</td>
          <td>185.0</td>
          <td>6</td>
          <td>17891.682785</td>
        </tr>
        <tr>
          <th>170</th>
          <td>other</td>
          <td>6 BHK</td>
          <td>1300.0</td>
          <td>6.0</td>
          <td>99.0</td>
          <td>6</td>
          <td>7615.384615</td>
        </tr>
        <tr>
          <th>176</th>
          <td>Kumaraswami Layout</td>
          <td>5 Bedroom</td>
          <td>600.0</td>
          <td>3.0</td>
          <td>85.0</td>
          <td>5</td>
          <td>14166.666667</td>
        </tr>
        <tr>
          <th>193</th>
          <td>other</td>
          <td>7 Bedroom</td>
          <td>1800.0</td>
          <td>7.0</td>
          <td>250.0</td>
          <td>7</td>
          <td>13888.888889</td>
        </tr>
        <tr>
          <th>258</th>
          <td>other</td>
          <td>5 Bedroom</td>
          <td>1200.0</td>
          <td>5.0</td>
          <td>170.0</td>
          <td>5</td>
          <td>14166.666667</td>
        </tr>
        <tr>
          <th>282</th>
          <td>other</td>
          <td>6 Bedroom</td>
          <td>1450.0</td>
          <td>6.0</td>
          <td>250.0</td>
          <td>6</td>
          <td>17241.379310</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df4.shape




.. parsed-literal::

    (13243, 7)



.. code:: ipython3

    df5= df4[~(df4.total_sqft/df4.bhk<300)]
    df5.shape




.. parsed-literal::

    (12499, 7)



.. code:: ipython3

    df5.shape




.. parsed-literal::

    (12499, 7)



.. code:: ipython3

    df5["price_per_sqft"].describe()




.. parsed-literal::

    count     12453.000000
    mean       6308.550780
    std        4168.588831
    min         267.829813
    25%        4210.526316
    50%        5294.117647
    75%        6916.666667
    max      176470.588235
    Name: price_per_sqft, dtype: float64



.. code:: ipython3

    def remove_pricesqft_outlier(df):
        vignesh=pd.DataFrame()
        for key,subdf in df.groupby('location'):
            m=np.mean(subdf.price_per_sqft)
            st=np.std(subdf.price_per_sqft)
            reduced_df=subdf[(subdf.price_per_sqft>(m-st))&(subdf.price_per_sqft<=(m+st))]
            vignesh=pd.concat([vignesh,reduced_df],ignore_index=True)
        return vignesh
    df6=remove_pricesqft_outlier(df5)
    df6.head(20)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>price_per_sqft</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1250.0</td>
          <td>2.0</td>
          <td>44.0</td>
          <td>3</td>
          <td>3520.000000</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1250.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>3200.000000</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Devarachikkanahalli</td>
          <td>2 Bedroom</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>83.0</td>
          <td>2</td>
          <td>6916.666667</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>3418.803419</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1425.0</td>
          <td>2.0</td>
          <td>65.0</td>
          <td>3</td>
          <td>4561.403509</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>947.0</td>
          <td>2.0</td>
          <td>43.0</td>
          <td>2</td>
          <td>4540.654699</td>
        </tr>
        <tr>
          <th>6</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1130.0</td>
          <td>2.0</td>
          <td>36.0</td>
          <td>2</td>
          <td>3185.840708</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1417.0</td>
          <td>2.0</td>
          <td>76.0</td>
          <td>3</td>
          <td>5363.443896</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1230.0</td>
          <td>2.0</td>
          <td>58.0</td>
          <td>2</td>
          <td>4715.447154</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1705.0</td>
          <td>3.0</td>
          <td>75.0</td>
          <td>3</td>
          <td>4398.826979</td>
        </tr>
        <tr>
          <th>10</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1116.0</td>
          <td>2.0</td>
          <td>47.0</td>
          <td>2</td>
          <td>4211.469534</td>
        </tr>
        <tr>
          <th>11</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>991.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>4036.326942</td>
        </tr>
        <tr>
          <th>12</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1700.0</td>
          <td>3.0</td>
          <td>71.0</td>
          <td>3</td>
          <td>4176.470588</td>
        </tr>
        <tr>
          <th>13</th>
          <td>1st Block Jayanagar</td>
          <td>4 BHK</td>
          <td>2850.0</td>
          <td>4.0</td>
          <td>428.0</td>
          <td>4</td>
          <td>15017.543860</td>
        </tr>
        <tr>
          <th>14</th>
          <td>1st Block Jayanagar</td>
          <td>3 BHK</td>
          <td>1630.0</td>
          <td>3.0</td>
          <td>194.0</td>
          <td>3</td>
          <td>11901.840491</td>
        </tr>
        <tr>
          <th>15</th>
          <td>1st Block Jayanagar</td>
          <td>3 BHK</td>
          <td>1875.0</td>
          <td>2.0</td>
          <td>235.0</td>
          <td>3</td>
          <td>12533.333333</td>
        </tr>
        <tr>
          <th>16</th>
          <td>1st Block Jayanagar</td>
          <td>3 BHK</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>130.0</td>
          <td>3</td>
          <td>10833.333333</td>
        </tr>
        <tr>
          <th>17</th>
          <td>1st Block Jayanagar</td>
          <td>2 BHK</td>
          <td>1235.0</td>
          <td>2.0</td>
          <td>148.0</td>
          <td>2</td>
          <td>11983.805668</td>
        </tr>
        <tr>
          <th>18</th>
          <td>1st Block Jayanagar</td>
          <td>4 BHK</td>
          <td>2750.0</td>
          <td>4.0</td>
          <td>413.0</td>
          <td>4</td>
          <td>15018.181818</td>
        </tr>
        <tr>
          <th>19</th>
          <td>1st Block Jayanagar</td>
          <td>4 BHK</td>
          <td>2450.0</td>
          <td>4.0</td>
          <td>368.0</td>
          <td>4</td>
          <td>15020.408163</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    def plot_scatter_chart(df,location):
        bhk2 = df[(df.location==location) & (df.bhk==2)]
        bhk3 = df[(df.location==location) & (df.bhk==3)]
        matplotlib.rcParams['figure.figsize'] = (13,8)
        plt.scatter(bhk2.total_sqft,bhk2.price,color='blue',label='2 BHK', s=50)
        plt.scatter(bhk3.total_sqft,bhk3.price,marker='+', color='green',label='3 BHK', s=50)
        plt.xlabel('Total Square Feet Area')
        plt.ylabel('Price (Lakh Indian Rupees)')
        plt.title(location)
        plt.legend()
    plot_scatter_chart(df6,"Rajaji Nagar")



.. image:: output_34_0.png


.. code:: ipython3

    df6.location.unique()




.. parsed-literal::

    array([' Devarachikkanahalli', '1st Block Jayanagar',
           '1st Phase JP Nagar', '2nd Phase Judicial Layout',
           '2nd Stage Nagarbhavi', '5th Block Hbr Layout',
           '5th Phase JP Nagar', '6th Phase JP Nagar', '7th Phase JP Nagar',
           '8th Phase JP Nagar', '9th Phase JP Nagar', 'AECS Layout',
           'Abbigere', 'Akshaya Nagar', 'Ambalipura', 'Ambedkar Nagar',
           'Amruthahalli', 'Anandapura', 'Ananth Nagar', 'Anekal',
           'Anjanapura', 'Ardendale', 'Arekere', 'Attibele', 'BEML Layout',
           'BTM 2nd Stage', 'BTM Layout', 'Babusapalaya', 'Badavala Nagar',
           'Balagere', 'Banashankari', 'Banashankari Stage II',
           'Banashankari Stage III', 'Banashankari Stage V',
           'Banashankari Stage VI', 'Banaswadi', 'Banjara Layout',
           'Bannerghatta', 'Bannerghatta Road', 'Basavangudi',
           'Basaveshwara Nagar', 'Battarahalli', 'Begur', 'Begur Road',
           'Bellandur', 'Benson Town', 'Bharathi Nagar', 'Bhoganhalli',
           'Billekahalli', 'Binny Pete', 'Bisuvanahalli', 'Bommanahalli',
           'Bommasandra', 'Bommasandra Industrial Area', 'Bommenahalli',
           'Brookefield', 'Budigere', 'CV Raman Nagar', 'Chamrajpet',
           'Chandapura', 'Channasandra', 'Chikka Tirupathi', 'Chikkabanavar',
           'Chikkalasandra', 'Choodasandra', 'Cooke Town', 'Cox Town',
           'Cunningham Road', 'Dasanapura', 'Dasarahalli', 'Devanahalli',
           'Dodda Nekkundi', 'Doddaballapur', 'Doddakallasandra',
           'Doddathoguru', 'Domlur', 'Dommasandra', 'EPIP Zone',
           'Electronic City', 'Electronic City Phase II',
           'Electronics City Phase 1', 'Frazer Town', 'GM Palaya',
           'Garudachar Palya', 'Giri Nagar', 'Gollarapalya Hosahalli',
           'Gottigere', 'Green Glen Layout', 'Gubbalala', 'Gunjur',
           'HAL 2nd Stage', 'HBR Layout', 'HRBR Layout', 'HSR Layout',
           'Haralur Road', 'Harlur', 'Hebbal', 'Hebbal Kempapura',
           'Hegde Nagar', 'Hennur', 'Hennur Road', 'Hoodi', 'Horamavu Agara',
           'Horamavu Banaswadi', 'Hormavu', 'Hosa Road', 'Hosakerehalli',
           'Hoskote', 'Hosur Road', 'Hulimavu', 'ISRO Layout', 'ITPL',
           'Iblur Village', 'Indira Nagar', 'JP Nagar', 'Jakkur', 'Jalahalli',
           'Jalahalli East', 'Jigani', 'Judicial Layout', 'KR Puram',
           'Kadubeesanahalli', 'Kadugodi', 'Kaggadasapura', 'Kaggalipura',
           'Kaikondrahalli', 'Kalena Agrahara', 'Kalyan nagar', 'Kambipura',
           'Kammanahalli', 'Kammasandra', 'Kanakapura', 'Kanakpura Road',
           'Kannamangala', 'Karuna Nagar', 'Kasavanhalli', 'Kasturi Nagar',
           'Kathriguppe', 'Kaval Byrasandra', 'Kenchenahalli', 'Kengeri',
           'Kengeri Satellite Town', 'Kereguddadahalli', 'Kodichikkanahalli',
           'Kodigehaali', 'Kodigehalli', 'Kodihalli', 'Kogilu', 'Konanakunte',
           'Koramangala', 'Kothannur', 'Kothanur', 'Kudlu', 'Kudlu Gate',
           'Kumaraswami Layout', 'Kundalahalli', 'LB Shastri Nagar',
           'Laggere', 'Lakshminarayana Pura', 'Lingadheeranahalli',
           'Magadi Road', 'Mahadevpura', 'Mahalakshmi Layout', 'Mallasandra',
           'Malleshpalya', 'Malleshwaram', 'Marathahalli', 'Margondanahalli',
           'Marsur', 'Mico Layout', 'Munnekollal', 'Murugeshpalya',
           'Mysore Road', 'NGR Layout', 'NRI Layout', 'Nagarbhavi',
           'Nagasandra', 'Nagavara', 'Nagavarapalya', 'Narayanapura',
           'Neeladri Nagar', 'Nehru Nagar', 'OMBR Layout', 'Old Airport Road',
           'Old Madras Road', 'Padmanabhanagar', 'Pai Layout', 'Panathur',
           'Parappana Agrahara', 'Pattandur Agrahara', 'Poorna Pragna Layout',
           'Prithvi Layout', 'R.T. Nagar', 'Rachenahalli',
           'Raja Rajeshwari Nagar', 'Rajaji Nagar', 'Rajiv Nagar',
           'Ramagondanahalli', 'Ramamurthy Nagar', 'Rayasandra',
           'Sahakara Nagar', 'Sanjay nagar', 'Sarakki Nagar', 'Sarjapur',
           'Sarjapur  Road', 'Sarjapura - Attibele Road',
           'Sector 2 HSR Layout', 'Sector 7 HSR Layout', 'Seegehalli',
           'Shampura', 'Shivaji Nagar', 'Singasandra', 'Somasundara Palya',
           'Sompura', 'Sonnenahalli', 'Subramanyapura', 'Sultan Palaya',
           'TC Palaya', 'Talaghattapura', 'Thanisandra', 'Thigalarapalya',
           'Thubarahalli', 'Thyagaraja Nagar', 'Tindlu', 'Tumkur Road',
           'Ulsoor', 'Uttarahalli', 'Varthur', 'Varthur Road', 'Vasanthapura',
           'Vidyaranyapura', 'Vijayanagar', 'Vishveshwarya Layout',
           'Vishwapriya Layout', 'Vittasandra', 'Whitefield',
           'Yelachenahalli', 'Yelahanka', 'Yelahanka New Town', 'Yelenahalli',
           'Yeshwanthpur', 'other'], dtype=object)



.. code:: ipython3

    def remove_bhk_outliers(df):
        vignesh=np.array([])
        for location,location_df in df.groupby("location"):
            bhk_stats={}
            for bhk,bhk_df in location_df.groupby("bhk"):
                bhk_stats[bhk]={
                               "mean":np.mean(bhk_df.price_per_sqft),
                               "std":np.std(bhk_df.price_per_sqft),
                               "count":bhk_df.shape[0]
               }
            for bhk,bhk_df in location_df.groupby("bhk"):
                stats=bhk_stats.get(bhk-1)
                if stats and stats["count"]>5:
                    vignesh=np.append(vignesh,bhk_df[bhk_df.price_per_sqft<(stats["mean"])].index.values)
        return df.drop(vignesh,axis="index")
    df7=remove_bhk_outliers(df6)
    df7.shape




.. parsed-literal::

    (7340, 7)



.. code:: ipython3

    plot_scatter_chart(df7,"Rajaji Nagar")



.. image:: output_37_0.png


.. code:: ipython3

    plt.hist(df7.price_per_sqft,rwidth=0.5)
    plt.xlabel("Price Per Square Feet")
    plt.ylabel("Count")




.. parsed-literal::

    Text(0, 0.5, 'Count')




.. image:: output_38_1.png


.. code:: ipython3

    plt.hist(df7.bath,rwidth=0.5)
    plt.xlabel("number of bathrooms")
    plt.ylabel("count")




.. parsed-literal::

    Text(0, 0.5, 'count')




.. image:: output_39_1.png


.. code:: ipython3

    df7[df7.bath>10]




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>price_per_sqft</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>5269</th>
          <td>Neeladri Nagar</td>
          <td>10 BHK</td>
          <td>4000.0</td>
          <td>12.0</td>
          <td>160.0</td>
          <td>10</td>
          <td>4000.000000</td>
        </tr>
        <tr>
          <th>8479</th>
          <td>other</td>
          <td>10 BHK</td>
          <td>12000.0</td>
          <td>12.0</td>
          <td>525.0</td>
          <td>10</td>
          <td>4375.000000</td>
        </tr>
        <tr>
          <th>8568</th>
          <td>other</td>
          <td>16 BHK</td>
          <td>10000.0</td>
          <td>16.0</td>
          <td>550.0</td>
          <td>16</td>
          <td>5500.000000</td>
        </tr>
        <tr>
          <th>9307</th>
          <td>other</td>
          <td>11 BHK</td>
          <td>6000.0</td>
          <td>12.0</td>
          <td>150.0</td>
          <td>11</td>
          <td>2500.000000</td>
        </tr>
        <tr>
          <th>9639</th>
          <td>other</td>
          <td>13 BHK</td>
          <td>5425.0</td>
          <td>13.0</td>
          <td>275.0</td>
          <td>13</td>
          <td>5069.124424</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df8 = df7[df7.bath<df7.bhk+2]
    df8.shape




.. parsed-literal::

    (7262, 7)



.. code:: ipython3

    df8.head(20)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>size</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>price_per_sqft</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1250.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>3200.000000</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Devarachikkanahalli</td>
          <td>2 Bedroom</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>83.0</td>
          <td>2</td>
          <td>6916.666667</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>3418.803419</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1425.0</td>
          <td>2.0</td>
          <td>65.0</td>
          <td>3</td>
          <td>4561.403509</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>947.0</td>
          <td>2.0</td>
          <td>43.0</td>
          <td>2</td>
          <td>4540.654699</td>
        </tr>
        <tr>
          <th>6</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1130.0</td>
          <td>2.0</td>
          <td>36.0</td>
          <td>2</td>
          <td>3185.840708</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1417.0</td>
          <td>2.0</td>
          <td>76.0</td>
          <td>3</td>
          <td>5363.443896</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1230.0</td>
          <td>2.0</td>
          <td>58.0</td>
          <td>2</td>
          <td>4715.447154</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Devarachikkanahalli</td>
          <td>3 BHK</td>
          <td>1705.0</td>
          <td>3.0</td>
          <td>75.0</td>
          <td>3</td>
          <td>4398.826979</td>
        </tr>
        <tr>
          <th>10</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>1116.0</td>
          <td>2.0</td>
          <td>47.0</td>
          <td>2</td>
          <td>4211.469534</td>
        </tr>
        <tr>
          <th>11</th>
          <td>Devarachikkanahalli</td>
          <td>2 BHK</td>
          <td>991.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>4036.326942</td>
        </tr>
        <tr>
          <th>13</th>
          <td>1st Block Jayanagar</td>
          <td>4 BHK</td>
          <td>2850.0</td>
          <td>4.0</td>
          <td>428.0</td>
          <td>4</td>
          <td>15017.543860</td>
        </tr>
        <tr>
          <th>14</th>
          <td>1st Block Jayanagar</td>
          <td>3 BHK</td>
          <td>1630.0</td>
          <td>3.0</td>
          <td>194.0</td>
          <td>3</td>
          <td>11901.840491</td>
        </tr>
        <tr>
          <th>15</th>
          <td>1st Block Jayanagar</td>
          <td>3 BHK</td>
          <td>1875.0</td>
          <td>2.0</td>
          <td>235.0</td>
          <td>3</td>
          <td>12533.333333</td>
        </tr>
        <tr>
          <th>16</th>
          <td>1st Block Jayanagar</td>
          <td>3 BHK</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>130.0</td>
          <td>3</td>
          <td>10833.333333</td>
        </tr>
        <tr>
          <th>17</th>
          <td>1st Block Jayanagar</td>
          <td>2 BHK</td>
          <td>1235.0</td>
          <td>2.0</td>
          <td>148.0</td>
          <td>2</td>
          <td>11983.805668</td>
        </tr>
        <tr>
          <th>18</th>
          <td>1st Block Jayanagar</td>
          <td>4 BHK</td>
          <td>2750.0</td>
          <td>4.0</td>
          <td>413.0</td>
          <td>4</td>
          <td>15018.181818</td>
        </tr>
        <tr>
          <th>19</th>
          <td>1st Block Jayanagar</td>
          <td>4 BHK</td>
          <td>2450.0</td>
          <td>4.0</td>
          <td>368.0</td>
          <td>4</td>
          <td>15020.408163</td>
        </tr>
        <tr>
          <th>21</th>
          <td>1st Phase JP Nagar</td>
          <td>3 BHK</td>
          <td>1875.0</td>
          <td>3.0</td>
          <td>167.0</td>
          <td>3</td>
          <td>8906.666667</td>
        </tr>
        <tr>
          <th>22</th>
          <td>1st Phase JP Nagar</td>
          <td>5 Bedroom</td>
          <td>1500.0</td>
          <td>5.0</td>
          <td>85.0</td>
          <td>5</td>
          <td>5666.666667</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df9 = df8.drop(['size','price_per_sqft'],axis='columns')
    df9.head(3)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>Devarachikkanahalli</td>
          <td>1250.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Devarachikkanahalli</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>83.0</td>
          <td>2</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Devarachikkanahalli</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    dummies = pd.get_dummies(df9.location)
    dummies.head(3)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Devarachikkanahalli</th>
          <th>1st Block Jayanagar</th>
          <th>1st Phase JP Nagar</th>
          <th>2nd Phase Judicial Layout</th>
          <th>2nd Stage Nagarbhavi</th>
          <th>5th Block Hbr Layout</th>
          <th>5th Phase JP Nagar</th>
          <th>6th Phase JP Nagar</th>
          <th>7th Phase JP Nagar</th>
          <th>8th Phase JP Nagar</th>
          <th>...</th>
          <th>Vishveshwarya Layout</th>
          <th>Vishwapriya Layout</th>
          <th>Vittasandra</th>
          <th>Whitefield</th>
          <th>Yelachenahalli</th>
          <th>Yelahanka</th>
          <th>Yelahanka New Town</th>
          <th>Yelenahalli</th>
          <th>Yeshwanthpur</th>
          <th>other</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>3 rows × 242 columns</p>
    </div>



.. code:: ipython3

    df10 = pd.concat([df9,dummies.drop('other',axis='columns')],axis='columns')
    df10.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>location</th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>Devarachikkanahalli</th>
          <th>1st Block Jayanagar</th>
          <th>1st Phase JP Nagar</th>
          <th>2nd Phase Judicial Layout</th>
          <th>2nd Stage Nagarbhavi</th>
          <th>...</th>
          <th>Vijayanagar</th>
          <th>Vishveshwarya Layout</th>
          <th>Vishwapriya Layout</th>
          <th>Vittasandra</th>
          <th>Whitefield</th>
          <th>Yelachenahalli</th>
          <th>Yelahanka</th>
          <th>Yelahanka New Town</th>
          <th>Yelenahalli</th>
          <th>Yeshwanthpur</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>Devarachikkanahalli</td>
          <td>1250.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Devarachikkanahalli</td>
          <td>1200.0</td>
          <td>2.0</td>
          <td>83.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Devarachikkanahalli</td>
          <td>1170.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Devarachikkanahalli</td>
          <td>1425.0</td>
          <td>2.0</td>
          <td>65.0</td>
          <td>3</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Devarachikkanahalli</td>
          <td>947.0</td>
          <td>2.0</td>
          <td>43.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 246 columns</p>
    </div>



.. code:: ipython3

    df11 = df10.drop('location',axis='columns')
    df11.head(2)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>price</th>
          <th>bhk</th>
          <th>Devarachikkanahalli</th>
          <th>1st Block Jayanagar</th>
          <th>1st Phase JP Nagar</th>
          <th>2nd Phase Judicial Layout</th>
          <th>2nd Stage Nagarbhavi</th>
          <th>5th Block Hbr Layout</th>
          <th>...</th>
          <th>Vijayanagar</th>
          <th>Vishveshwarya Layout</th>
          <th>Vishwapriya Layout</th>
          <th>Vittasandra</th>
          <th>Whitefield</th>
          <th>Yelachenahalli</th>
          <th>Yelahanka</th>
          <th>Yelahanka New Town</th>
          <th>Yelenahalli</th>
          <th>Yeshwanthpur</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>1250.0</td>
          <td>2.0</td>
          <td>40.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1200.0</td>
          <td>2.0</td>
          <td>83.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>2 rows × 245 columns</p>
    </div>



.. code:: ipython3

    ab= df11.drop(['price'],axis='columns')
    ab.head(3)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>total_sqft</th>
          <th>bath</th>
          <th>bhk</th>
          <th>Devarachikkanahalli</th>
          <th>1st Block Jayanagar</th>
          <th>1st Phase JP Nagar</th>
          <th>2nd Phase Judicial Layout</th>
          <th>2nd Stage Nagarbhavi</th>
          <th>5th Block Hbr Layout</th>
          <th>5th Phase JP Nagar</th>
          <th>...</th>
          <th>Vijayanagar</th>
          <th>Vishveshwarya Layout</th>
          <th>Vishwapriya Layout</th>
          <th>Vittasandra</th>
          <th>Whitefield</th>
          <th>Yelachenahalli</th>
          <th>Yelahanka</th>
          <th>Yelahanka New Town</th>
          <th>Yelenahalli</th>
          <th>Yeshwanthpur</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>1250.0</td>
          <td>2.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1200.0</td>
          <td>2.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1170.0</td>
          <td>2.0</td>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>3 rows × 244 columns</p>
    </div>



.. code:: ipython3

    X=ab.copy()

.. code:: ipython3

    y = df11.price

.. code:: ipython3

    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.25,random_state=7)

.. code:: ipython3

    from sklearn.linear_model import LinearRegression
    X.dropna(inplace=True)
    y.dropna(inplace=True)
    classifier = LinearRegression()
    classifier.fit(X_train,y_train)
    classifier.score(X_test,y_test)




.. parsed-literal::

    0.8922874083597758



.. code:: ipython3

    def predict_price(location,sqft,bath,bhk):    
        loc_index = np.where(X.columns==location)[0][0]
    
        x = np.zeros(len(X.columns))
        x[0] = sqft
        x[1] = bath
        x[2] = bhk
        if loc_index >= 0:
            x[loc_index] = 1
    
        return classifier.predict([x])[0]

.. code:: ipython3

    predict_price('1st Phase JP Nagar',1000, 2, 2)




.. parsed-literal::

    86.40835290897846



.. code:: ipython3

    predict_price('Indira Nagar',1000, 2, 2)




.. parsed-literal::

    147.50776080657855



.. code:: ipython3

    predict_price('Indira Nagar',1000, 3, 3)




.. parsed-literal::

    146.9263670861259



